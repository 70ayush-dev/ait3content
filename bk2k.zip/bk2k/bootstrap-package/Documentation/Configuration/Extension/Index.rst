﻿.. include:: /Includes.rst.txt

.. _extension-configuration:

=======================
Extension Configuration
=======================

Use the :ref:`Extension Manager <t3coreapi:extension-manager>` to adjust the
Bootstrap Package to your needs.

PageTsConfig
============

The Bootstrap Package has a lot of PageTsConfig defaults.
In some cases it can be useful to deactivate some of them if you do not need
them.

.. TODO:
   All PageTsConfig properties should be listed here - as already done
   with the sibling chapters "Image Rendering" and "TypoScript".
